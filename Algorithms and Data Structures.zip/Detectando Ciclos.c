#include<stdio.h>
#include<stdlib.h>
typedef struct lista{
    int info;
    struct lista *prox;
    struct lista *ant;
}TLista;
typedef TLista *PLista;
 
PLista inicializa(){
    return NULL;
}
 
int verifica_se_aquele_elemento_esta_na_lista(PLista p,int x){
    PLista aux=p;
    while(aux!=NULL&&aux->info!=x){
        aux=aux->prox;
    }
    if(aux==NULL){
        return 0;
    }
    if(aux->info==x){
        //o elemento esta na Lista
        return 1;
    }
}
 
PLista remover_um_vertice_analisado(PLista p,int x){
    if(p==NULL){
        //printf("Lista Vazia. Não foi Possível Remover!\n");
        return p;
    }
    PLista aux=p;
    while(aux!=NULL&&aux->info!=x){
        aux=aux->prox;
    }
    if(aux==NULL){
        //printf("Elemento não Encontrado. Não foi Possível Remover!\n");
        return p;
    }
    if(aux==p){
       // printf("O Elemento a ser Removido é o Primeiro da Lista!\n");
        p=p->prox;
        if(p!=NULL){
            p->ant=NULL;
        }
        free(aux);
        return p;
    }
    if(aux->prox!=NULL){
        aux->prox->ant=aux->ant;
    }
    if(aux->ant!=NULL){
        aux->ant->prox=aux->prox;
    }
    return p;
}
 
PLista insere(PLista p,int x){
    PLista novo=(PLista)malloc(sizeof(TLista));
    if(p==NULL){
        novo->prox=NULL;
        novo->ant=NULL;
        novo->info=x;
        return novo;
    }
    novo->info=x;
    novo->prox=p;
    p->ant=novo;
    return novo;
}
 
void imprime(PLista p){
    if(p==NULL){
        //printf("Lista Vazia!\n");
        return;
    }
    PLista aux=p;
    while(aux!=NULL){
        printf("%d ",aux->info);
        aux=aux->prox;
    }
    printf("\n");
}
 
void libera(PLista p){
    PLista aux=p;
    while(p!=NULL){
        aux=p;
        p=p->prox;
        free(aux);
    }
}
 
int main(){
    int c,p;
    int x,y;
    int i,j;
    int resposta=0;
    PLista lista=inicializa();
    scanf("%d%d",&c,&p);
    int matriz[c][c];
    for(i=0;i<c;i++){
        for(j=0;j<c;j++){
            matriz[i][j]=0;
        }
    }
    for(i=0;i<p;i++){
        scanf("%d%d",&x,&y);
        x--;
        y--;
        matriz[x][y]=1;
        matriz[y][x]=1;
    }
  /*  for(i=0;i<c;i++){
        for(j=0;j<c;j++){
            printf("%d ",matriz[i][j]);
        }
        printf("\n");
    }
    */
    for(i=0;i<c;i++){
        for(j=0;j<c;j++){
            if(j>i&&matriz[i][j]){
                if(!(verifica_se_aquele_elemento_esta_na_lista(lista,j+1))){
                    lista=insere(lista,j+1);
                }
                else{
                    resposta++;
                }
                //imprime(lista);
            }
        }
        lista=remover_um_vertice_analisado(lista,i+2);
        //imprime(lista);
    }
    //LEMBRAR DE LIBERAR A MEMORIA NO FINAL
    libera(lista);
    printf("%d\n",resposta);
    return 0;
}