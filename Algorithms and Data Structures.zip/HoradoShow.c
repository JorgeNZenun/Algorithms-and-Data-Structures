#include <stdio.h>
#include <stdlib.h>
typedef struct no{
    int info;
    struct no* prox;
}TNo;
typedef TNo *PNo;
 
typedef struct fila{
    PNo ini;
    PNo fim;
}TFila;
typedef TFila *PFila;
 
PFila cria(){
    PFila f=(PFila)malloc(sizeof(TFila));
    f->ini=f->fim=NULL;
    return(f);
}
 
PFila insere(PFila f, int v){
    PNo novo;
    novo=(PNo)malloc(sizeof(TNo));
    novo->info=v;
    novo->prox=NULL;
    if(f->fim==NULL){
        f->ini=f->fim=novo;
    }
    else{
        f->fim->prox=novo;
        f->fim=novo;
    }
    return(f);
}
 
void libera(PFila f){
    PNo p,aux;
    p=f->ini;
    while(p!=NULL){
        aux=p;
        p=p->prox;
        free(aux);
    }
    free(f);
}
 
int somar_e_encontrar_maior_valor(PFila f, int quantidade_de_itens){
    int soma=100;
    int maior_valor=100;
    PNo p;
    for(p=f->ini;p!=NULL;p=p->prox){
        soma+=p->info;
        if(soma>maior_valor){
            maior_valor=soma;
        }
    }
    return(maior_valor);
}
 
 
int main(){
    int i;
    int numero_de_caixas_do_jogo;
    int conteudo_da_caixa_correspondente;
    int maior_valor_encontrado;
    scanf("%d",&numero_de_caixas_do_jogo);
    PFila fila;
    fila=cria();
    for(i=0;i<numero_de_caixas_do_jogo;i++){
        scanf("%d",&conteudo_da_caixa_correspondente);
        insere(fila, conteudo_da_caixa_correspondente);
    }
    maior_valor_encontrado=somar_e_encontrar_maior_valor(fila, numero_de_caixas_do_jogo);
    printf("%d\n",maior_valor_encontrado);
    libera(fila);
    return 0;
}