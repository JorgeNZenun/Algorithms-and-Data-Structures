#include <stdio.h>
#include <stdlib.h>
typedef struct lista{
    int info;
    struct lista *anterior;
    struct lista *proximo;
}TLista;
typedef TLista *PLista;
 
PLista inicializa(){
    return NULL;
}
 
PLista insere(PLista l,int x){
    PLista novo=(PLista)malloc(sizeof(TLista));
    novo->info=x;
    novo->proximo=NULL;
    if(l==NULL){
        novo->anterior=NULL;
        return novo;
    }
    PLista aux=l;
    while(aux->proximo!=NULL){
        aux=aux->proximo;
    }
    aux->proximo=novo;
    novo->anterior=aux;
    return l;
}
 
int tempo_total(PLista casas,PLista cartas) {
    int tempo=0;
    PLista carta_atual=cartas;
    PLista casa_atual=casas;
    while(carta_atual!=NULL){
        while(casa_atual->info!=carta_atual->info){
            if(carta_atual->info<casa_atual->info){
                tempo++;
                casa_atual=casa_atual->anterior;
            }else{
                tempo++;
                casa_atual=casa_atual->proximo;
            }
        }
        carta_atual=carta_atual->proximo;
    }
    return tempo;
}
 
 
void libera(PLista l){
    PLista aux;
    while(l!=NULL){
        aux=l->proximo;
        free(l);
        l=aux;
    }
}
 
void imprime(PLista l){
    PLista aux=l;
    while(aux!=NULL){
        printf("%d ",aux->info);
        aux=aux->proximo;
    }
    printf("\n");
    return;
}
 
 
int main(){
    int i;
    int tempo_busca;
    int numero_de_casas,numero_de_cartas;
    int x_casa;
    int x_carta;
    PLista casas=inicializa();
    PLista cartas=inicializa();
    scanf("%d%d",&numero_de_casas,&numero_de_cartas);
    for(i=0;i<numero_de_casas;i++){
        scanf("%d",&x_casa);
        casas=insere(casas,x_casa);
    }
    for(i=0;i<numero_de_cartas;i++){
        scanf("%d",&x_carta);
        cartas=insere(cartas,x_carta);
    }
    printf("%d\n",tempo_total(casas,cartas));
    libera(casas);
    libera(cartas);
    return 0;
}