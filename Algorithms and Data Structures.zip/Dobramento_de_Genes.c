#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct pilha{
    char letra;
    struct pilha *prox;
}TPilha;
typedef TPilha *PPilha;
 
PPilha inicializa_pilha(){
        return NULL;
    }
    
PPilha insere_pilha_e_verifica_dobra(PPilha l, char c,int *n){
    if(l!=NULL&&l->letra==c){
        PPilha topo = l;
        l=l->prox;
        free(topo);
        (*n)++;
        return l;
    }
    else{
    PPilha novo = (PPilha)malloc(sizeof(TPilha));
    novo->letra=c;
    novo->prox=l;
    return novo;
    }
}
 
void imprime_pilha(PPilha l){
    PPilha aux=l;
    if(aux==NULL){
        printf("pilha vazia");
    }
    while(aux!=NULL){
        printf("%c",aux->letra);
        aux=aux->prox;
    }
    printf("\n");
}
int main(){
    char string[4000000];
    int i,numero_de_pares_removidos;
    numero_de_pares_removidos=0;
    fgets(string,4000000,stdin);
    int quantidade_de_caracteres;
    quantidade_de_caracteres=strlen(string)-1;
    PPilha pilha=inicializa_pilha();
    for(i=0;i<quantidade_de_caracteres;i++){
        pilha= insere_pilha_e_verifica_dobra(pilha,string[i],&numero_de_pares_removidos);
        //imprime_pilha(pilha);
        //printf("%d\n",numero_de_pares_removidos);
    }
    printf("%d\n",quantidade_de_caracteres-numero_de_pares_removidos);
    return 0;
}