#include <stdio.h>
#include <stdlib.h>
 
struct convidado {
    int beleza;
    long int fortuna;
    int doacao;
};
int verifica_possibilidade(struct convidado *Convidados[],int indices[],int tam) {
    int i,j;
    for(i=0;i<tam;i++){
        for(j=i+1;j<tam;j++){
            if((Convidados[indices[i]]->beleza>Convidados[indices[j]]->beleza&&Convidados[indices[i]]->fortuna<=Convidados[indices[j]]->fortuna)||(Convidados[indices[i]]->fortuna>Convidados[indices[j]]->fortuna&&Convidados[indices[i]]->beleza <= Convidados[indices[j]]->beleza)||(Convidados[indices[j]]->beleza>Convidados[indices[i]]->beleza&&Convidados[indices[j]]->fortuna<=Convidados[indices[i]]->fortuna)||(Convidados[indices[j]]->fortuna>Convidados[indices[i]]->fortuna&&Convidados[indices[j]]->beleza<=Convidados[indices[i]]->beleza)){
                return 0;
            }
        }
    }
    return 1;
}
long int calcular_soma_doacoes(struct convidado *Convidados[], int indices[], int tam) {
    long int soma=0;
    int i;
    for(i=0;i<tam;i++){
        soma+=Convidados[indices[i]]->doacao;
    }
    return soma;
}
int main() {
    int numero_de_convidados,i,j,k;
    scanf("%d",&numero_de_convidados);
    struct convidado *Convidados[numero_de_convidados];
    for (i=0;i<numero_de_convidados;i++) {
        Convidados[i]=(struct convidado *)malloc(sizeof(struct convidado));
        scanf("%d %ld %d",&Convidados[i]->beleza,&Convidados[i]->fortuna,&Convidados[i]->doacao);
    }
    long int melhor_soma=0;
    int melhor_combinacao[numero_de_convidados];
    int num_melhores=0;
 
    for(i=1;i<(1<<numero_de_convidados);i++){
        int num_selecionados=0;
        int indices[numero_de_convidados];
        for(j=0;j<numero_de_convidados;j++) {
            if(i&(1<<j)){
                indices[num_selecionados++]=j;
            }
        }
        if(verifica_possibilidade(Convidados,indices,num_selecionados)) {
            long int soma=calcular_soma_doacoes(Convidados,indices,num_selecionados);
            if (soma>melhor_soma) {
                melhor_soma=soma;
            }
        }
    }
    printf("%ld\n",melhor_soma);
    for(i=0;i<numero_de_convidados;i++){
        free(Convidados[i]);
    }
 
    return 0;
}