#include<stdlib.h>
#include<stdio.h>
 
typedef struct no *pme;
struct no{
    int col,val;
    pme prox;
};
typedef pme matriz[1000];
 
void inicializa(matriz m,int l){
    int i;
    for(i=0;i<l;i++){
        m[i]=NULL;
    }
} 
 
void insere(matriz m,int l,int c,int v){
    pme novo,p;
    novo=(pme)malloc(sizeof(struct no));
    novo->col=c;
    novo->val=v;
    novo->prox=NULL;
    if(m[l]==NULL){
        m[l]=novo;
    }else{
        p=m[l];
        while(p->prox!=NULL){
            p=p->prox;
        }
        p->prox=novo;
    }
}
 
void libera(matriz m,int l){
    pme p,q;
    int i;
    for(i=0;i<l;i++){
        for(p=m[i];p!=NULL;){
            q=p;
            p=p->prox;
            free(q);
        }
    }
}
 
int verifica_e_remove(matriz m,int plin, int pcol){
    pme p;
    p=m[plin-1];
    while(p!=NULL&&p->col<pcol-1){
        p=p->prox;
    }
    if(p!=NULL&&p->col==pcol-1){
        if(p->val>0){
            p->val--;
            return 1;
        }
    }
    return 0;
}
 
int main(){
    matriz m;
    int lin,col,i,j,val,n,resposta;
    scanf("%d%d",&lin,&col);
    inicializa(m,lin);
    for(i=0;i<lin;i++){
        for(j=0;j<col;j++){
            scanf("%d",&val);
            if(val!=0){
                insere(m,i,j,val);
            }
        }
    }
    resposta=0;
    int plin,pcol;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d%d",&plin,&pcol);
        if(verifica_e_remove(m,plin,pcol)){
            resposta++;
        }
    }
    printf("%d\n",resposta);
    libera(m,lin);
    return 0;
}