#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
 
typedef struct arvore{
    char info[50];
    struct arvore *esq;
    struct arvore *dir;
}TArv;
typedef TArv *PArv;
 
PArv criar(){
    PArv a=(PArv)malloc(sizeof(TArv));
    a->esq=NULL;
    a->dir=NULL;
    return a;
}
 
PArv inserir(PArv a,char *string){
    if(a==NULL){
        a=criar();
        strcpy(a->info,string);
        return a;
    }
    if(strcmp(a->info,string)<0){
        //a palavra vem depois
        a->dir=inserir(a->dir,string);
    }else if(strcmp(a->info,string)>0){
        //a palavra vem antes
        a->esq=inserir(a->esq,string);
    }
    return a;
}
    
void imprimir(PArv a){
    if(a==NULL){
        return;
    }imprimir(a->esq);
    printf("%s\n",a->info);
    imprimir(a->dir);
}
 
void libera(PArv a){
    if(a==NULL){
        return;
    }
    libera(a->esq);
    libera(a->dir);
    free(a);
}
 
int main(){
    int i,j;
    int qtd_de_palavras;
    char string[50];
    PArv arvore=NULL;
    scanf("%d",&qtd_de_palavras);
    for(i=0;i<qtd_de_palavras;i++){
        scanf("%s",string);
        for(j=0;string[j]!='\0';j++){
            string[j]=tolower(string[j]);
        }
        arvore=inserir(arvore,string);
    }
    imprimir(arvore);
    libera(arvore);
    return 0;
}